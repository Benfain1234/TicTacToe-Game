package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ImageButton[][] buttons = new ImageButton[3][3];
    ImageView currentText;
    ImageView winLine;
    ImageButton playAgain;
    int currentTextResID;
    int winLineResID;
    int x_img;
    int o_img;
    int gameCount;
    boolean x_Plays; // if true X plays else O plays

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        x_Plays = true;
        gameCount = 0;
        x_img = getResources().getIdentifier("x","drawable",getPackageName());
        o_img = getResources().getIdentifier("o","drawable",getPackageName());
        currentText = findViewById(R.id.game_current_img);
        playAgain = findViewById(R.id.play_again);
        playAgain.setOnClickListener(view -> gameReset());

        for(int j, i = 0; i < 3; i++) {
            for(j = 0; j < 3; j++) {
                buttons[i][j] = findViewById(getResources().getIdentifier("button" + i + j,"id", getPackageName()));
                buttons[i][j].setOnClickListener(this);
            }
        }
    }

    @Override
    public void onClick(View view) {
        if(view.getTag() != null || gameWin()) {
            return; // already clicked button or game is on win state
        }
        if(x_Plays) { // X clicked
            view.setTag("X");
            ((ImageButton) view).setImageResource(x_img);
            currentTextResID = getResources().getIdentifier("oplay","drawable",getPackageName()); // now O turn img
            if(gameWin()) {
                currentTextResID = getResources().getIdentifier("xwin","drawable",getPackageName()); // X win img
                currentText.setImageResource(currentTextResID);
            }
        }
        else { // O clicked
            view.setTag("O");
            ((ImageButton) view).setImageResource(o_img);
            currentTextResID = getResources().getIdentifier("xplay","drawable",getPackageName()); // now X turn img
            if(gameWin()) {
                currentTextResID = getResources().getIdentifier("owin","drawable",getPackageName()); // O win img
                currentText.setImageResource(currentTextResID);
            }
        }
        gameCount++;
        if(9 == gameCount && !gameWin()) {
            currentTextResID = getResources().getIdentifier("nowin","drawable",getPackageName()); // draw img
            currentText.setImageResource(currentTextResID);
            playAgain.setVisibility(View.VISIBLE);
        }

        x_Plays = !x_Plays; //change x_Play status to its opposite
        currentText.setImageResource(currentTextResID);
    }

    boolean gameWin() {
        for (int i = 0; i < 3; i++) {
            if (buttons[i][0].getTag() == buttons[i][1].getTag() // row i, pos 0 and 1 are equal
                    && buttons[i][2].getTag() == buttons[i][0].getTag() // row i, pos 0 and 1 are equal
                    && buttons[i][0].getTag() != null) {// make sure row i pos 0 is not null
                winLineResID = getResources().getIdentifier("win_line_row_" + (i+1),"id",getPackageName());
                winLine = findViewById(winLineResID);
                
                winLine.setVisibility(View.VISIBLE);
                playAgain.setVisibility(View.VISIBLE);
                return true; // win for the i row
            }
        }
        for (int i = 0; i < 3; i++) {
            if (buttons[0][i].getTag() == buttons[1][i].getTag() // col i, pos 0 and 1 are equal
                    && buttons[2][i].getTag() == buttons[0][i].getTag() // col i, pos 0 and 1 are equal
                    && buttons[0][i].getTag() != null) {// make sure col i pos 0 is not null
                winLineResID = getResources().getIdentifier("win_line_col_" + (i+1),"id",getPackageName());
                winLine = findViewById(winLineResID);
                winLine.setVisibility(View.VISIBLE);
                playAgain.setVisibility(View.VISIBLE);
                return true; // win for the i col
            }
        }
        if (buttons[0][0].getTag() == buttons[1][1].getTag()
                && buttons[2][2].getTag() == buttons[0][0].getTag()
                && buttons[0][0].getTag() != null) {
            winLineResID = getResources().getIdentifier("win_line_back_slash","id",getPackageName());
            winLine = findViewById(winLineResID);
            winLine.setVisibility(View.VISIBLE);
            playAgain.setVisibility(View.VISIBLE);
            return true; // win for a "\"
        }
        if (buttons[0][2].getTag() == buttons[1][1].getTag()
                && buttons[0][2].getTag() == buttons[2][0].getTag()
                && buttons[0][2].getTag() != null) {
            winLineResID = getResources().getIdentifier("win_line_slash","id",getPackageName());
            winLine = findViewById(winLineResID);
            winLine.setVisibility(View.VISIBLE);
            playAgain.setVisibility(View.VISIBLE);
            return true; // win for a "/"
        }
        return false;
    }
    void gameReset(){

        for(int j, i = 0; i < 3; i++) {
            for(j = 0; j < 3; j++) {
                buttons[i][j].setImageResource(R.drawable.empty);
                buttons[i][j].setTag(null);
            }
        }
        currentTextResID = getResources().getIdentifier("xplay","drawable",getPackageName());
        currentText.setImageResource(currentTextResID);
        winLine.setVisibility(View.INVISIBLE);
        playAgain.setVisibility(View.INVISIBLE);
        gameCount = 0;
        x_Plays = true;
    }
}